import { Mail, Phone, Users } from "lucide-react";

export default function DadosBasicos({
  errors,
  handleNumericInputChange,
  handleInputChange,
  formData,
}) {
  console.log(formData);
  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
        <Users className="w-6 h-6 text-amber-500" />
        Dados Básicos
      </h3>

      <div>
        <label className="text-slate-300 text-sm mb-2 block">
          Nome da Barbearia *
        </label>
        <input
          type="text"
          name="name"
          value={formData?.name ?? ""}
          onChange={handleInputChange}
          className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
          placeholder="Ex: Barbershop Classic"
        />
        {errors.name && (
          <p className="text-red-400 text-sm mt-1">{errors.name}</p>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label className="text-slate-300 text-sm mb-2 block">Email *</label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="email"
              name="email"
              value={formData?.email || ""}
              onChange={handleInputChange}
              className="w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
              placeholder="contato@barbearia.com"
            />
          </div>
          {errors.email && (
            <p className="text-red-400 text-sm mt-1">{errors.email}</p>
          )}
        </div>

        <div>
          <label className="text-slate-300 text-sm mb-2 block">
            Telefone *
          </label>
          <div className="relative">
            <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="tel"
              name="phone"
              value={formData?.phone || ""}
              onChange={handleNumericInputChange}
              className="w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
              placeholder="(11) 98765-4321"
            />
          </div>
          {errors.phone && (
            <p className="text-red-400 text-sm mt-1">{errors.phone}</p>
          )}
        </div>
      </div>

      <div>
        <label className="text-slate-300 text-sm mb-2 block">WhatsApp</label>
        <div className="relative">
          <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="tel"
            name="whatsapp"
            value={formData?.whatsapp || ""}
            onChange={handleNumericInputChange}
            className="w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
            placeholder="(11) 98765-4321"
          />
        </div>
      </div>
    </div>
  );
}
