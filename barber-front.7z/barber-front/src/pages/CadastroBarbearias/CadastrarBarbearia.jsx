import React, { useState } from "react";
import { Check, Loader } from "lucide-react";
import Etapas from "./Etapas";
import Endereco from "./Endereco";
import Detalhes from "./Detalhes";
import Servicos from "./Servicos";
import DadosBasicos from "./DadosBasicos";
import api from "../../services/api";
import { useNavigate } from "react-router-dom";

export default function CadastrarBarbearia() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    whatsapp: "",
    description: "",
    priceRange: "",
    address: {
      cep: "",
      street: "",
      number: "",
      complement: "",
      neighborhood: "",
      city: "",
      state: "",
    },
    selectedDays: [],
    openTime: [],
    services: [
      // name
      // price
      // duration
    ],
  });

  const [errors, setErrors] = useState({});

  const handleNumericInputChange = (e) => {
    const { name, value } = e.target;
    const numericValue = value.replace(/[^0-9]/g, "");

    setFormData((prev) => ({
      ...prev,
      [name]: numericValue,
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleAddressChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      address: {
        ...prev.address,
        [name]: value,
      },
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validateStep = (currentStep) => {
    const newErrors = {};

    if (currentStep === 1) {
      if (!formData.name) newErrors.name = "Nome é obrigatório";
      if (!formData.email) newErrors.email = "Email é obrigatório";
      if (!formData.phone) newErrors.phone = "Telefone é obrigatório";
    }

    if (currentStep === 2) {
      if (!formData.address.cep) newErrors.cep = "CEP é obrigatório";
      if (!formData.address.street) newErrors.street = "Rua é obrigatória";
      if (!formData.address.number) newErrors.number = "Número é obrigatório";
      if (!formData.address.neighborhood)
        newErrors.neighborhood = "Bairro é obrigatório";
      if (!formData.address.city) newErrors.city = "Cidade é obrigatória";
      if (!formData.address.state) newErrors.state = "Estado é obrigatório";
    }

    if (currentStep === 3) {
      if (!formData.description)
        newErrors.description = "Descrição é obrigatória";
      if (!formData.priceRange)
        newErrors.priceRange = "Faixa de preço é obrigatória";
      if (formData.selectedDays.length === 0)
        newErrors.selectedDays = "Selecione pelo menos um dia";
      if (!formData.openHour)
        newErrors.openHour = "Horário de abertura é obrigatório";
      if (!formData.closeHour)
        newErrors.closeHour = "Horário de fechamento é obrigatório";
      if (formData.openHour > formData.closeHour)
        newErrors.openHour =
          "Horário de abertura maior que horário de fechamento!";
    }

    if (currentStep === 4) {
      if (formData.services.length === 0)
        newErrors.services = "Selecione pelo menos um serviço";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const nextStep = () => {
    if (validateStep(step)) {
      setStep((prev) => prev + 1);
    }
  };

  const prevStep = () => {
    setStep((prev) => prev - 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    if (!validateStep(step)) {
      setLoading(false);
      return;
    }

    try {
      const response = await api.post("/barber/create", formData);
      if (response.status === 201) {
        alert("Barbearia cadastrada com sucesso!");
      }
    } catch (error) {
      if (error.status === 409) {
        alert("Já existe uma barbearia cadastrada com esses dados!");
      } else {
        alert("Erro ao cadastrar barbearia!");
      }
    } finally {
      navigate("/explorar");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-6 py-12 max-w-4xl">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Cadastre sua Barbearia
          </h2>
          <p className="text-xl text-slate-300">
            Preencha os dados e comece a atrair novos clientes
          </p>
        </div>

        <div className="mb-12">
          <Etapas step={step} />
        </div>

        <form>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-8">
            {step === 1 && (
              <DadosBasicos
                errors={errors}
                handleNumericInputChange={handleNumericInputChange}
                handleInputChange={handleInputChange}
                formData={formData}
              />
            )}

            {step === 2 && (
              <Endereco
                formData={formData}
                handleNumericInputChange={handleNumericInputChange}
                handleAddressChange={handleAddressChange}
                errors={errors}
                setFormData={setFormData}
                setErrors={setErrors}
              />
            )}

            {step === 3 && (
              <Detalhes
                formData={formData}
                handleInputChange={handleInputChange}
                errors={errors}
                setFormData={setFormData}
              />
            )}

            {step === 4 && (
              <Servicos
                formData={formData}
                errors={errors}
                setFormData={setFormData}
              />
            )}

            <div className="flex justify-between mt-8">
              {step > 1 && (
                <button
                  type="button"
                  onClick={prevStep}
                  className="bg-white/10 hover:bg-white/20 text-white font-semibold px-8 py-3 rounded-lg transition"
                >
                  Voltar
                </button>
              )}

              {step < 4 ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="bg-amber-500 hover:bg-amber-600 text-black font-semibold px-8 py-3 rounded-lg transition ml-auto"
                >
                  Próximo
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={loading}
                  className="cursor-pointer bg-amber-500 hover:bg-amber-600 text-black font-semibold px-8 py-3 rounded-lg transition ml-auto flex items-center gap-2 disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <Loader className="w-5 h-5 animate-spin" />
                      Cadastrando...
                    </>
                  ) : (
                    <>
                      <Check className="w-5 h-5" />
                      Finalizar Cadastro
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
