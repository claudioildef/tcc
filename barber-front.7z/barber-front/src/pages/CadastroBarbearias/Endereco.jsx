import { Loader, MapPin } from "lucide-react";
import { useState } from "react";

export default function Endereco({
  formData,
  handleAddressChange,
  errors,
  setFormData,
  setErrors,
}) {
  const [loadingCep, setLoadingCep] = useState(false);

  const fetchAddressByCep = async (cep) => {
    const cleanCep = cep.replace(/\D/g, "");

    if (cleanCep.length !== 8) {
      return;
    }

    setLoadingCep(true);

    try {
      const response = await fetch(
        `https://viacep.com.br/ws/${cleanCep}/json/`
      );
      const data = await response.json();

      if (data.erro) {
        setErrors((prev) => ({ ...prev, cep: "CEP não encontrado" }));
        setLoadingCep(false);
        return;
      }

      setFormData((prev) => ({
        ...prev,
        address: {
          ...prev.address,
          street: data.logradouro || "",
          neighborhood: data.bairro || "",
          city: data.localidade || "",
          state: data.uf || "",
        },
      }));

      setErrors((prev) => ({ ...prev, cep: "" }));
    } catch (error) {
      console.log(error);
      setErrors((prev) => ({ ...prev, cep: "Erro ao buscar CEP" }));
    } finally {
      setLoadingCep(false);
    }
  };

  const handleCepChange = (e) => {
    let value = e.target.value.replace(/\D/g, "");

    if (value.length > 8) {
      value = value.slice(0, 8);
    }

    if (value.length > 5) {
      value = value.replace(/^(\d{5})(\d)/, "$1-$2");
    }

    setFormData((prev) => ({
      ...prev,
      address: { ...prev.address, cep: value },
    }));

    if (value.replace(/\D/g, "").length === 8) {
      fetchAddressByCep(value);
    }
  };

  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
        <MapPin className="w-6 h-6 text-amber-500" />
        Endereço
      </h3>

      <div>
        <label className="text-slate-300 text-sm mb-2 block">CEP *</label>
        <div className="relative">
          <input
            type="text"
            name="cep"
            value={formData.address.cep}
            onChange={handleCepChange}
            maxLength={9}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
            placeholder="00000-000"
          />
          {loadingCep && (
            <Loader className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-amber-500 animate-spin" />
          )}
        </div>
        {errors.cep && (
          <p className="text-red-400 text-sm mt-1">{errors.cep}</p>
        )}
        <p className="text-slate-400 text-xs mt-1">
          Digite o CEP para preencher o endereço automaticamente
        </p>
      </div>

      <div>
        <label className="text-slate-300 text-sm mb-2 block">Rua *</label>
        <input
          type="text"
          name="street"
          value={formData.address.street}
          onChange={(e) => handleAddressChange(e)}
          className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
          placeholder="Nome da rua"
        />
        {errors.street && (
          <p className="text-red-400 text-sm mt-1">{errors.street}</p>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label className="text-slate-300 text-sm mb-2 block">Número *</label>
          <input
            type="text"
            name="number"
            value={formData.address.number}
            onChange={handleAddressChange}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
            placeholder="123"
          />
          {errors.number && (
            <p className="text-red-400 text-sm mt-1">{errors.number}</p>
          )}
        </div>

        <div>
          <label className="text-slate-300 text-sm mb-2 block">
            Complemento
          </label>
          <input
            type="text"
            name="complement"
            value={formData.address.complement}
            onChange={handleAddressChange}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
            placeholder="Apto, Sala, etc"
          />
        </div>
      </div>

      <div>
        <label className="text-slate-300 text-sm mb-2 block">Bairro *</label>
        <input
          type="text"
          name="neighborhood"
          value={formData.address.neighborhood}
          onChange={handleAddressChange}
          className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
          placeholder="Nome do bairro"
        />
        {errors.neighborhood && (
          <p className="text-red-400 text-sm mt-1">{errors.neighborhood}</p>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label className="text-slate-300 text-sm mb-2 block">Cidade *</label>
          <input
            type="text"
            name="city"
            value={formData.address.city}
            onChange={handleAddressChange}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
            placeholder="Cidade"
          />
          {errors.city && (
            <p className="text-red-400 text-sm mt-1">{errors.city}</p>
          )}
        </div>

        <div>
          <label className="text-slate-300 text-sm mb-2 block">Estado *</label>
          <input
            type="text"
            name="state"
            value={formData.address.state}
            onChange={handleAddressChange}
            maxLength={2}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition uppercase"
            placeholder="SP"
          />
          {errors.state && (
            <p className="text-red-400 text-sm mt-1">{errors.state}</p>
          )}
        </div>
      </div>
    </div>
  );
}
