import { Check } from "lucide-react";
import React from "react";

export default function Etapas({step}) {
    return (
        <div className="flex justify-between items-center">
            {[
                { num: 1, label: 'Dados Básicos' },
                { num: 2, label: 'Endereço' },
                { num: 3, label: 'Detalhes' },
                { num: 4, label: 'Serviços' }
            ].map((s, idx) => (
                <React.Fragment key={s.num}>
                    <div className="flex flex-col items-center">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold transition ${step >= s.num ? 'bg-amber-500 text-black' : 'bg-white/10 text-slate-400'
                            }`}>
                            {step > s.num ? <Check className="w-6 h-6" /> : s.num}
                        </div>
                        <span className={`text-sm mt-2 ${step >= s.num ? 'text-amber-500' : 'text-slate-400'}`}>
                            {s.label}
                        </span>
                    </div>
                    {idx < 3 && (
                        <div className={`flex-1 h-1 mx-4 rounded transition ${step > s.num ? 'bg-amber-500' : 'bg-white/10'
                            }`} />
                    )}
                </React.Fragment>
            ))}
        </div>
    )
}
