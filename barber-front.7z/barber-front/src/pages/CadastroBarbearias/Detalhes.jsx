import { Clock } from "lucide-react";

const daysOfWeek = [
  "Segunda-feira",
  "Terça-feira",
  "Quarta-feira",
  "Quinta-feira",
  "Sexta-feira",
  "Sábado",
  "Domingo",
];

export default function Detalhes({
  formData,
  handleInputChange,
  errors,
  setFormData,
}) {
  const handleDayToggle = (day) => {
    setFormData((prev) => ({
      ...prev,
      selectedDays: [
        ...(prev.selectedDays.includes(day)
          ? [...prev.selectedDays.filter((d) => d !== day)]
          : [...prev.selectedDays, day]),
      ],
    }));
  };

  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
        <Clock className="w-6 h-6 text-amber-500" />
        Detalhes da Barbearia
      </h3>

      <div>
        <label className="text-slate-300 text-sm mb-2 block">Descrição *</label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleInputChange}
          rows={4}
          className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition resize-none"
          placeholder="Descreva sua barbearia, ambiente, diferenciais..."
        />
        {errors.description && (
          <p className="text-red-400 text-sm mt-1">{errors.description}</p>
        )}
      </div>

      <div>
        <label className="text-slate-300 text-sm mb-2 block">
          Faixa de Preço *
        </label>
        <div className="grid grid-cols-3 gap-4">
          {["$", "$$", "$$$"].map((price) => (
            <button
              key={price}
              type="button"
              onClick={() =>
                setFormData((prev) => ({ ...prev, priceRange: price }))
              }
              className={`py-3 rounded-lg font-semibold transition ${
                formData.priceRange === price
                  ? "bg-amber-500 text-black"
                  : "bg-white/5 text-white border border-white/10 hover:border-amber-500/50"
              }`}
            >
              {price}{" "}
              {price === "$"
                ? "Econômico"
                : price === "$$"
                ? "Moderado"
                : "Premium"}
            </button>
          ))}
        </div>
        {errors.priceRange && (
          <p className="text-red-400 text-sm mt-1">{errors.priceRange}</p>
        )}
      </div>

      <div>
        <label className="text-slate-300 text-sm mb-2 block">
          Dias de Funcionamento *
        </label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {daysOfWeek.map((day) => (
            <button
              key={day}
              type="button"
              onClick={() => handleDayToggle(day)}
              className={`py-2 px-3 rounded-lg text-sm font-semibold transition ${
                formData.selectedDays.includes(day)
                  ? "bg-amber-500 text-black"
                  : "bg-white/5 text-white border border-white/10 hover:border-amber-500/50"
              }`}
            >
              {day.substring(0, 3)}
            </button>
          ))}
        </div>
        {errors.openDays && (
          <p className="text-red-400 text-sm mt-1">{errors.openDays}</p>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label className="text-slate-300 text-sm mb-2 block">
            Horário de Abertura *
          </label>
          <input
            type="time"
            name="openHour"
            value={formData.openHour}
            onChange={handleInputChange}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition"
          />
          {errors.openHour && (
            <p className="text-red-400 text-sm mt-1">{errors.openHour}</p>
          )}
        </div>

        <div>
          <label className="text-slate-300 text-sm mb-2 block">
            Horário de Fechamento *
          </label>
          <input
            type="time"
            name="closeHour"
            value={formData.closeHour}
            onChange={handleInputChange}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-amber-500 transition"
          />
          {errors.closeHour && (
            <p className="text-red-400 text-sm mt-1">{errors.closeHour}</p>
          )}
        </div>
      </div>
    </div>
  );
}
