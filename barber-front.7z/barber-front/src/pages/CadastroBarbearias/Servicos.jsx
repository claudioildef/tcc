import { Scissors } from "lucide-react";
import { useEffect, useState } from "react";

export default function Servicos({ formData, errors, setFormData }) {
  const [service, setService] = useState({
    name: "",
    description: "",
    price: "",
    duration: "",
  });

  const handleService = (e) => {
    const { name, value } = e.target;
    if (name === "price") {
      const numericValue = value.replace(/[^0-9]/g, "");
      setService((prev) => ({
        ...prev,
        [name]: numericValue,
      }));
    } else if (value !== undefined) {
      setService((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const handleRemoveService = (index) => {
    setFormData((prev) => ({
      ...prev,
      services: prev.services.filter((_, i) => i !== index),
    }));
  };

  const handleAddService = () => {
    if (service.name && service.price && service.duration) {
      setFormData((prev) => ({
        ...prev,
        services: [...prev.services, service],
      }));
      setService({
        name: "",
        description: "",
        price: "",
        duration: "",
      });
    }
  };

  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
        <Scissors className="w-6 h-6 text-amber-500" />
        Serviços Oferecidos
      </h3>

      <div>
        <label className="text-slate-300 text-sm mb-4 block">
          Adicione os serviços *
        </label>
        <div className="flex gap-2 w-full">
          <div className="flex flex-col w-[30%] gap-2">
            <input
              type="text"
              name="name"
              value={service.name ?? ""}
              onChange={(e) => handleService(e)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
              placeholder="Nome Ex: Corte + Barba"
            />
            <input
              type="text"
              name="price"
              value={service.price ?? ""}
              onChange={(e) => handleService(e)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
              placeholder="Preço Ex: 30.99"
            />
            <input
              type="text"
              name="duration"
              value={service.duration ?? ""}
              onChange={(e) => handleService(e)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
              placeholder="Duração Ex: 30m - 1h"
            />
          </div>
          <div className="flex items-end">
            <button
              type="button"
              onClick={() => handleAddService()}
              className={`cursor-pointer py-1 px-3 rounded-lg font-semibold transition text-left bg-amber-500 text-black`}
            >
              +
            </button>
          </div>

          {formData.services.length <= 0 ? (
            <p className="text-red-400 text-sm mt-1">
              Adicione pelo menos um serviço
            </p>
          ) : (
            <div className="w-full overflow-x-auto flex gap-2 scrollbar-thin scrollbar-thumb-amber-500 scrollbar-track-transparent">
              {formData.services.map((service, index) => {
                return (
                  <div
                    key={index}
                    className="relative flex-shrink-0 p-2 flex flex-col min-w-[150px] rounded-lg bg-amber-500 text-black"
                  >
                    <span
                      onClick={() => handleRemoveService(index)}
                      className="absolute right-3 top-1 cursor-pointer"
                    >
                      x
                    </span>
                    <span className="text-center font-bold">
                      Serviço {index + 1}
                    </span>
                    <span className="text-sm">Nome: {service.name}</span>
                    <span className="text-sm">Preço: {service.price}</span>
                    <span className="text-sm">Duração: {service.duration}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="bg-white/5 border border-white/10 rounded-lg p-6 mt-8">
        <h4 className="text-white font-semibold mb-4">Resumo do Cadastro</h4>
        <div className="space-y-2 text-slate-300">
          <p>
            <span className="text-amber-500">Nome:</span> {formData.name || "-"}
          </p>
          <p>
            <span className="text-amber-500">Email:</span>{" "}
            {formData.email || "-"}
          </p>
          <p>
            <span className="text-amber-500">Endereço:</span>{" "}
            {formData.address.street
              ? `${formData.address.street}, ${formData.address.number} - ${formData.address.city}/${formData.address.state}`
              : "-"}
          </p>
          <p>
            <span className="text-amber-500">Horário:</span>{" "}
            {formData.openHour && formData.closeHour
              ? `${formData.openHour} às ${formData.closeHour}`
              : "-"}
          </p>
        </div>
      </div>
    </div>
  );
}
