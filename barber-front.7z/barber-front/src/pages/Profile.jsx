import { useState } from "react";
import { useAuth } from "../context/AuthContext";

export default function Profile() {
  const { user, setUser } = useAuth();
  const [name, setName] = useState(user?.name || "");
  const [email, setEmail] = useState(user?.email || "");

  function save() {
    // update local users store (MVP)
    const users = JSON.parse(localStorage.getItem("bm_users") || "[]");
    const idx = users.findIndex(u => u.id === user.id);
    if (idx !== -1) {
      users[idx] = { ...users[idx], name, email };
      localStorage.setItem("bm_users", JSON.stringify(users));
    }
    setUser({ ...user, name, email });
    alert("Perfil atualizado");
  }

  return (
    <div className="max-w-md bg-gray-800 p-6 rounded">
      <h3 className="text-xl font-semibold mb-3">Perfil</h3>
      <label className="text-sm">Nome</label>
      <input className="w-full p-2 mb-2 rounded bg-gray-700" value={name} onChange={e => setName(e.target.value)} />
      <label className="text-sm">Email</label>
      <input className="w-full p-2 mb-4 rounded bg-gray-700" value={email} onChange={e => setEmail(e.target.value)} />
      <button className="px-4 py-2 bg-indigo-600 rounded" onClick={save}>Salvar</button>
    </div>
  );
}