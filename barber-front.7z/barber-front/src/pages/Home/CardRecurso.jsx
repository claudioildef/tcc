import { MapPin, Scissors, Star } from "lucide-react"

export default function CardRecurso({ title, desc, icon }) {
    const iconMap = {
        scissors: <Scissors className="w-6 h-6 text-amber-500" />,
        map: <MapPin className="w-6 h-6 text-amber-500" />,
        star: <Star className="w-6 h-6 text-amber-500" />
    }
    return (
        <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 hover:bg-white/10 transition">
            <div className="w-12 h-12 bg-amber-500/20 rounded-lg flex items-center justify-center mb-4">
                {iconMap[icon]}
            </div>
            <h3 className="text-xl font-semibold text-white mb-3">{title}</h3>
            <p className="text-slate-400">
                {desc}
            </p>
        </div>
    )
}