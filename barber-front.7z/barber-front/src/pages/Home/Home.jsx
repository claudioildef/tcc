import React, { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, MapPin, Star, Scissors } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Destaques from './Destaques';
import CardRecurso from './CardRecurso';
import api from '../../services/api';

const cardsData = [
  {
    title: 'Gestão Completa',
    desc: 'Gerencie serviços, horários e profissionais em um único lugar de forma intuitiva.',
    icon: 'scissors',
  },
  {
    title: 'Localize Facilmente',
    desc: 'Encontre barbearias próximas com avaliações e informações detalhadas.',
    icon: 'map',
  },
  {
    title: 'Destaque seu Negócio',
    desc: 'Apareça em destaque e conquiste mais clientes com nosso sistema de recomendação.',
    icon: 'star',
  }
]

const featuredShopsEx = [
  {
    name: "Barbershop Classic",
    location: "Centro, São Paulo - SP",
    image: "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=400&h=300&fit=crop"
  },
  {
    name: "The Gentleman's Cut",
    location: "Jardins, São Paulo - SP",
    image: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=400&h=300&fit=crop"
  },
  {
    name: "Urban Barbers",
    location: "Vila Mariana, São Paulo - SP",
    image: "https://images.unsplash.com/photo-1621605815971-fbc98d665033?w=400&h=300&fit=crop"
  },
  {
    name: "Corte & Estilo",
    location: "Pinheiros, São Paulo - SP",
    image: "https://images.unsplash.com/photo-1622286342621-4bd786c2447c?w=400&h=300&fit=crop"
  },
  {
    name: "Master Barber Studio",
    location: "Moema, São Paulo - SP",
    image: "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?w=400&h=300&fit=crop"
  }
];

export default function Home() {

  const navigate = useNavigate()
  const [featuredShops, setFeaturedShops] = useState()

  const fetchFeaturedShops = async () => {
    try {
      const res = await api.get('/barber/getFeatured');
      if (res.status) {
        setFeaturedShops(res.data)
      }
    } catch (error) {
      console.log(error)
    }

  }

  useEffect(() => {
    fetchFeaturedShops()
  }, [])

  return (
    <div className="min-h-screen">
      <section className="container mx-auto px-6 py-20">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h2 className="text-5xl font-bold text-white mb-6 leading-tight">
            Encontre a Barbearia Perfeita para Você
          </h2>
          <p className="text-xl text-slate-300 mb-8 leading-relaxed">
            O Barber+ é a plataforma completa para conectar você às melhores barbearias da sua região.
            Cadastre seu estabelecimento, gerencie agendamentos e alcance novos clientes de forma simples e eficiente.
          </p>
          <div className="flex gap-4 justify-center ">
            <button onClick={() => navigate('/cadastrar')} className="cursor-pointer bg-amber-500 hover:bg-amber-600 text-black font-semibold px-8 py-3 rounded-lg transition transform hover:scale-105">
              Cadastrar Barbearia
            </button>
            <button onClick={() => navigate('/explorar')} className="cursor-pointer bg-white/10 hover:bg-white/20 text-white font-semibold px-8 py-3 rounded-lg backdrop-blur-sm border border-white/20 transition">
              Explorar Barbearias
            </button>
          </div>
        </div>
        <div className="grid md:grid-cols-3 gap-6 mb-20">
          {cardsData.map((card, index) => {
            <CardRecurso key={index} title={card.title} desc={card.desc} icon={card.icon} />
          })}
        </div>

        <div>
          <Destaques featuredShops={featuredShops || featuredShopsEx} />
        </div>
      </section>

    </div>
  );
};