import { ChevronLeft, ChevronRight, MapPin, Star } from "lucide-react";
import { useState } from "react";

export default function Destaques({ featuredShops }) {
    const [currentSlide, setCurrentSlide] = useState(0);

    const nextSlide = () => {
        setCurrentSlide((prev) => (prev + 1) % featuredShops.length);
    };

    const prevSlide = () => {
        setCurrentSlide((prev) => (prev - 1 + featuredShops.length) % featuredShops.length);
    };

    const goToSlide = (index) => {
        setCurrentSlide(index);
    };

    return (
        <div className="relative">
            <div className="max-w-6xl mx-auto">
                <h3 className="text-3xl font-bold text-white text-center mb-10">
                    Barbearias em Destaque
                </h3>
                <div className="overflow-hidden rounded-2xl">
                    <div
                        className="flex transition-transform duration-500 ease-out"
                        style={{ transform: `translateX(-${currentSlide * 100}%)` }}
                    >
                        {featuredShops.map((shop, index) => (
                            <div key={index} className="min-w-full px-2">
                                <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl overflow-hidden hover:border-amber-500/50 transition">
                                    <div className="h-64 overflow-hidden">
                                        <img
                                            src={shop.image}
                                            alt={shop.name}
                                            className="w-full h-full object-cover hover:scale-110 transition duration-500"
                                        />
                                    </div>
                                    <div className="p-6">
                                        <h4 className="text-2xl font-bold text-white mb-3">{shop.name}</h4>
                                        <div className="flex items-center gap-2 text-slate-300">
                                            <MapPin className="w-5 h-5 text-amber-500" />
                                            <span>{shop.location}</span>
                                        </div>
                                        <div className="flex items-center gap-1 mt-4">
                                            {[...Array(5)].map((_, i) => (
                                                <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                                            ))}
                                            <span className="text-slate-400 ml-2">(4.9)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <button
                    onClick={prevSlide}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full backdrop-blur-sm transition"
                >
                    <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                    onClick={nextSlide}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full backdrop-blur-sm transition"
                >
                    <ChevronRight className="w-6 h-6" />
                </button>
                <div className="flex justify-center gap-2 mt-6">
                    {featuredShops.map((_, index) => (
                        <button
                            key={index}
                            onClick={() => goToSlide(index)}
                            className={`w-2 h-2 rounded-full transition ${currentSlide === index ? 'bg-amber-500 w-8' : 'bg-white/30'
                                }`}
                        />
                    ))}
                </div>
            </div>

        </div>
    )
}