import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function AuthPage() {
  const { user, setUser } = useAuth();
  const [mode, setMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    if (user) navigate("/");
  }, [user, navigate]);

  function register() {
    if (!name || !email || !password) return alert("Preencha todos os campos");
    // Save basic user to localStorage (MVP)
    const users = JSON.parse(localStorage.getItem("bm_users") || "[]");
    if (users.find(u => u.email === email)) return alert("Email já cadastrado");
    const newUser = { id: Date.now(), name, email, password };
    users.push(newUser);
    localStorage.setItem("bm_users", JSON.stringify(users));
    login({ id: newUser.id, name: newUser.name, email: newUser.email });
    navigate("/");
  }

  function login() {
    const users = JSON.parse(localStorage.getItem("bm_users") || "[]");
    const found = users.find(u => u.email === email && u.password === password);
    if (!found) return alert("Credenciais inválidas");
    setUser({ id: found.id, name: found.name, email: found.email });
    navigate("/");
  }


  return (
    <div className="max-w-md mx-auto mt-8 bg-[#211308] p-6 rounded-lg">
      <div className="flex justify-around mb-4">
        <button className={`px-3 py-1 cursor-pointer ${mode === 'login' ? 'bg-[#856145]' : ''} rounded`} onClick={() => setMode('login')}>Login</button>
        <button className={`px-3 py-1 cursor-pointer ${mode === 'register' ? 'bg-[#856145]' : ''} rounded`} onClick={() => setMode('register')}>Cadastro</button>

      </div>

      {mode === 'register' && (
        <input className="w-full p-2 mb-2 rounded bg-white text-gray-700" placeholder="Nome" value={name} onChange={e => setName(e.target.value)} />
      )}
      <input className="w-full p-2 mb-2 rounded bg-white text-gray-700" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
      <input className="w-full p-2 mb-4 rounded bg-white text-gray-700" placeholder="Senha" type="password" value={password} onChange={e => setPassword(e.target.value)} />

      {mode === 'login' ? (
        <button className="w-full py-2 bg-[#856145] rounded" onClick={login}>Entrar</button>
      ) : (
        <button className="w-full py-2 bg-[#856145] rounded" onClick={register}>Cadastrar</button>
      )}
    </div>
  );
}