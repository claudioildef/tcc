import React, { useState } from "react";
import {
  X,
  MapPin,
  Phone,
  Mail,
  Star,
  Clock,
  DollarSign,
  MessageCircle,
  Calendar,
  User,
  Send,
} from "lucide-react";
import api from "../../services/api";
import dayjs from "dayjs";

export default function ModalBarbearia({ barber, isOpen, onClose }) {
  const [activeTab, setActiveTab] = useState("info");
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const activeBarber = barber[0];

  if (!isOpen) return null;

  const calculateAverageRating = (reviews) => {
    if (!reviews || reviews.length === 0) {
      return 0;
    }

    const totalRating = reviews.reduce((accumulator, currentReview) => {
      return accumulator + currentReview.rating;
    }, 0);

    return (totalRating / reviews.length).toFixed(2);
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();

    if (!rating || !customerName.trim()) {
      alert("Por favor, preencha seu nome e selecione uma avaliação");
      return;
    }

    setSubmitting(true);
    try {
      const response = await api.post("/review", {
        barberId: activeBarber.id,
        customerName: customerName.trim(),
        rating: rating,
      });

      if (response.status === 201) {
        setSubmitSuccess(true);
        setTimeout(() => {
          setRating(0);
          setReviewText("");
          setCustomerName("");
          setSubmitSuccess(false);
          onClose();
        }, 2000);
      }
    } catch (error) {
      console.error("Erro ao enviar avaliação:", error);
      alert("Erro ao enviar avaliação. Tente novamente.");
    } finally {
      setSubmitting(false);
    }
  };

  // Ordenar horários por dia da semana
  const diasOrdem = [
    "Segunda-feira",
    "Terça-feira",
    "Quarta-feira",
    "Quinta-feira",
    "Sexta-feira",
    "Sábado",
    "Domingo",
  ];

  const sortedWorkingHours = barber.workingHours
    ? [...barber.workingHours].sort(
        (a, b) =>
          diasOrdem.indexOf(a.dayOfWeek) - diasOrdem.indexOf(b.dayOfWeek)
      )
    : [];

  const averageRating = calculateAverageRating(activeBarber.reviews);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-slate-900 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl border border-white/10">
        <div className="relative h-64 overflow-hidden">
          <img
            src={activeBarber.logo}
            alt={activeBarber.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent" />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 backdrop-blur-sm text-white p-2 rounded-full transition"
          >
            <X className="w-6 h-6" />
          </button>
          <div className="absolute bottom-6 left-6 right-6">
            <h2 className="text-3xl font-bold text-white mb-2">
              {activeBarber.name}
            </h2>
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-1 bg-black/50 backdrop-blur-sm px-3 py-1 rounded-full">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(averageRating)
                        ? "fill-amber-500 text-amber-500"
                        : "text-slate-600"
                    }`}
                  />
                ))}
                <span className="text-white font-semibold ml-2">
                  {averageRating}
                </span>
                <span className="text-slate-300 text-sm ml-1">
                  ({activeBarber.reviews.length})
                </span>
              </div>
              <div className="flex items-center gap-1 bg-black/50 backdrop-blur-sm px-3 py-1 rounded-full">
                <DollarSign className="w-4 h-4 text-amber-500" />
                <span className="text-white font-semibold">
                  {activeBarber.priceRange}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-b border-white/10">
          <div className="flex">
            <button
              onClick={() => setActiveTab("info")}
              className={`flex-1 py-4 font-semibold transition ${
                activeTab === "info"
                  ? "text-amber-500 border-b-2 border-amber-500"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Informações
            </button>
            <button
              onClick={() => setActiveTab("reviews")}
              className={`flex-1 py-4 font-semibold transition ${
                activeTab === "reviews"
                  ? "text-amber-500 border-b-2 border-amber-500"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Avaliações
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-400px)] p-6">
          {activeTab === "info" ? (
            <div className="space-y-6">
              {activeBarber.description && (
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    Sobre
                  </h3>
                  <p className="text-slate-300">{activeBarber.description}</p>
                </div>
              )}

              {activeBarber.services && activeBarber.services.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-white mb-3">
                    Serviços
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {activeBarber.services.map((service, index) => (
                      <div
                        key={index}
                        className="flex flex-col bg-amber-500/10 text-amber-500 px-4 py-2 rounded-lg border border-amber-500/20 font-medium"
                      >
                        <span>{service.name}</span>
                        <span> {"R$ " + service.price}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {sortedWorkingHours.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-white mb-3">
                    Horário de Funcionamento
                  </h3>
                  <div className="space-y-2">
                    {sortedWorkingHours.map((hour) => (
                      <div
                        key={hour.id}
                        className="flex items-center justify-between bg-white/5 p-3 rounded-lg"
                      >
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-amber-500" />
                          <span className="text-white font-medium">
                            {hour.dayOfWeek}
                          </span>
                        </div>
                        <span className="text-slate-300">
                          {hour.openTime.slice(0, 5)} -{" "}
                          {hour.closeTime.slice(0, 5)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <h3 className="text-lg font-semibold text-white mb-3">
                  Contato
                </h3>
                <div className="space-y-3">
                  {activeBarber.address && (
                    <div className="flex items-start gap-3 bg-white/5 p-3 rounded-lg">
                      <MapPin className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-white font-medium">Endereço</p>
                        <p className="text-slate-300 text-sm">
                          {activeBarber.address.street},{" "}
                          {activeBarber.address.number}
                          {activeBarber.address.complement &&
                            ` - ${activeBarber.address.complement}`}
                        </p>
                        <p className="text-slate-300 text-sm">
                          {activeBarber.address.neighborhood},{" "}
                          {activeBarber.address.city} -{" "}
                          {activeBarber.address.state}
                        </p>
                        <p className="text-slate-400 text-xs">
                          CEP: {activeBarber.address.cep}
                        </p>
                      </div>
                    </div>
                  )}

                  {activeBarber.phone && (
                    <a
                      href={`tel:${activeBarber.phone}`}
                      className="flex items-center gap-3 bg-white/5 p-3 rounded-lg hover:bg-white/10 transition"
                    >
                      <Phone className="w-5 h-5 text-amber-500" />
                      <div>
                        <p className="text-white font-medium">Telefone</p>
                        <p className="text-slate-300 text-sm">
                          {activeBarber.phone}
                        </p>
                      </div>
                    </a>
                  )}

                  {activeBarber.whatsapp && (
                    <a
                      href={`https://wa.me/${activeBarber.whatsapp.replace(
                        /\D/g,
                        ""
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 bg-white/5 p-3 rounded-lg hover:bg-white/10 transition"
                    >
                      <MessageCircle className="w-5 h-5 text-amber-500" />
                      <div>
                        <p className="text-white font-medium">WhatsApp</p>
                        <p className="text-slate-300 text-sm">
                          {activeBarber.whatsapp}
                        </p>
                      </div>
                    </a>
                  )}

                  {activeBarber.email && (
                    <a
                      href={`mailto:${activeBarber.email}`}
                      className="flex items-center gap-3 bg-white/5 p-3 rounded-lg hover:bg-white/10 transition"
                    >
                      <Mail className="w-5 h-5 text-amber-500" />
                      <div>
                        <p className="text-white font-medium">E-mail</p>
                        <p className="text-slate-300 text-sm">
                          {activeBarber.email}
                        </p>
                      </div>
                    </a>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-white/5 p-6 rounded-xl border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-4">
                  Deixe sua avaliação
                </h3>
                <form onSubmit={handleSubmitReview} className="space-y-4">
                  <div>
                    <label className="block text-slate-300 mb-2 text-sm">
                      Seu nome
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Digite seu nome"
                        className="w-full bg-white/5 border border-white/10 rounded-lg pl-11 pr-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-2 text-sm">
                      Avaliação
                    </label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          className="transition-transform hover:scale-110"
                        >
                          <Star
                            className={`w-8 h-8 ${
                              star <= (hoverRating || rating)
                                ? "fill-amber-500 text-amber-500"
                                : "text-slate-600"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={submitting || submitSuccess}
                    className={`w-full py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2 ${
                      submitSuccess
                        ? "bg-green-500 text-white"
                        : submitting
                        ? "bg-amber-500/50 text-black/50 cursor-not-allowed"
                        : "bg-amber-500 hover:bg-amber-600 text-black"
                    }`}
                  >
                    {submitSuccess ? (
                      <>
                        <span>✓</span> Avaliação enviada!
                      </>
                    ) : submitting ? (
                      "Enviando..."
                    ) : (
                      <>
                        <Send className="w-5 h-5" />
                        Enviar Avaliação
                      </>
                    )}
                  </button>
                </form>
              </div>

              <div className="flex flex-col gap-2">
                <h3 className="text-lg font-semibold text-white mb-2">
                  Avaliações
                </h3>
                {activeBarber.reviews?.map((r) => {
                  return (
                    <div className="flex justify-between p-3 rounded-lg bg-white/5 border border-white/10 flex">
                      <div>
                        <span className="font-bold text-lg">
                          {r.customerName}
                        </span>
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < Math.floor(r.rating)
                                  ? "fill-amber-500 text-amber-500"
                                  : "text-slate-600"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <span>
                        {dayjs(r.createdAt).format("DD/MM/YYYY HH:mm")}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
        <div className="border-t border-white/10 p-6 bg-slate-900/50">
          <button
            onClick={onClose}
            className="w-full bg-white/5 hover:bg-white/10 text-white font-semibold py-3 rounded-lg transition border border-white/10"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
