import React, { useEffect, useMemo, useState } from "react";
import {
  Search,
  MapPin,
  Star,
  Clock,
  DollarSign,
  Scissors,
  Filter,
  X,
} from "lucide-react";
import CardBarbearia from "./CardBarbearia";
import Filtros from "./Filtros";
import api from "../../services/api";
import ModalBarbearia from "./ModalBarbearia";

export default function Barbearias() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCity, setSelectedCity] = useState("all");
  const [showFilters, setShowFilters] = useState(false);
  const [barbearias, setBarbearias] = useState();
  const [cardBarbeariasData, setCardBabeariasData] = useState();
  const [citiesForFilter, setCitiesForFilter] = useState();
  const [barberDetails, setBarberDetails] = useState();
  const [minRating, setMinRating] = useState("");
  const [selectedPrice, setSelectedPrice] = useState("");
  const [open, setOpen] = useState(false);

  const filteredShops = useMemo(() => {
    if (!cardBarbeariasData) {
      return [];
    }
    return cardBarbeariasData.filter((shop) => {
      const searchMatch =
        shop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        shop.location.toLowerCase().includes(searchTerm.toLowerCase());

      const cityMatch =
        selectedCity === "all" || shop.location.includes(selectedCity);

      const ratingMatch =
        minRating === "" || parseFloat(shop.rating) >= parseFloat(minRating);

      const priceMatch = selectedPrice === "" || shop.price === selectedPrice;

      return searchMatch && cityMatch && ratingMatch && priceMatch;
    });
  }, [cardBarbeariasData, searchTerm, selectedCity, minRating, selectedPrice]);

  const getUniqueCities = (barbearias) => {
    console.log(barbearias);
    if (!barbearias || barbearias.length === 0) {
      return [];
    }
    const allCities = barbearias.map((barbearia) => barbearia.address.city);
    const uniqueCitiesSet = new Set(allCities);
    return [...uniqueCitiesSet].sort();
  };

  const getFormattedHoursSummary = (workingHours) => {
    if (!workingHours || workingHours.length === 0) {
      return "Fechado";
    }
    const dayOrder = [
      "Domingo",
      "Segunda-feira",
      "Terça-feira",
      "Quarta-feira",
      "Quinta-feira",
      "Sexta-feira",
      "Sábado",
    ];

    const sortedDays = workingHours
      .map((wh) => wh.dayOfWeek)
      .sort((a, b) => dayOrder.indexOf(a) - dayOrder.indexOf(b));
    const firstDay = sortedDays[0];
    const lastDay = sortedDays[sortedDays.length - 1];
    const firstDayAbbr = firstDay.substring(0, 3);
    const lastDayAbbr = lastDay.substring(0, 3);
    const openTime = workingHours[0].openTime.split(":")[0];
    const closeTime = workingHours[0].closeTime.split(":")[0];
    return `${firstDayAbbr}-${lastDayAbbr}: ${openTime}h-${closeTime}h`;
  };

  const calculateAverageRating = (reviews) => {
    if (!reviews || reviews.length === 0) {
      return 0;
    }

    const totalRating = reviews.reduce((accumulator, currentReview) => {
      return accumulator + currentReview.rating;
    }, 0);

    const average = totalRating / reviews.length;

    return average.toFixed(2);
  };

  const clearFiltros = () => {
    setSelectedCity("");
    setSelectedPrice("");
    setMinRating("");
    setSearchTerm("");
  };

  const fetchBarbearias = async () => {
    try {
      const res = await api.get("/barber");
      if (res.status) {
        setBarbearias(res.data);
        setCardBabeariasData(
          res.data.map((barber) => {
            return {
              id: barber.id,
              name: barber.name,
              location:
                barber.address.neighborhood +
                " - " +
                barber.address.city +
                ", " +
                barber.address.state,
              rating: calculateAverageRating(barber.reviews),
              reviews: barber.reviews.length,
              price: barber.priceRange,
              openHours: getFormattedHoursSummary(barber.workingHours),
              services: barber.services.map((s) => s.name),
              image: barber.logo,
            };
          })
        );
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleOpenModal = (barber) => {
    setOpen(true);
    setBarberDetails(barber);
  };

  const handleCloseModal = () => {
    setOpen(false);
    setBarberDetails();
    fetchBarbearias();
  };

  useEffect(() => {
    if (barbearias) {
      setCitiesForFilter(getUniqueCities(barbearias));
    }
  }, [barbearias]);

  useEffect(() => {
    if (open) {
      const scrollbarWidth =
        window.innerWidth - document.documentElement.clientWidth;
      document.body.style.paddingRight = `${scrollbarWidth}px`;
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.style.paddingRight = "";
      document.body.classList.remove("overflow-hidden");
    }

    return () => {
      document.body.style.paddingRight = "";
      document.body.classList.remove("overflow-hidden");
    };
  }, [open]);

  useEffect(() => {
    fetchBarbearias();
  }, []);

  return (
    <div className={`min-h-screen ${open ? "overflow-hidden" : ""}`}>
      <div className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Explore as Melhores Barbearias
          </h2>
          <p className="text-xl text-slate-300">
            Encontre o corte perfeito perto de você
          </p>
        </div>
        <div className="max-w-4xl mx-auto mb-12">
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
            <div className="flex gap-4 flex-wrap">
              <div className="flex-1 min-w-64 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar por nome ou localização..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition"
                />
              </div>

              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="bg-white/5 border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-amber-500 transition"
              >
                <option className="text-black" value="all">
                  Todas as cidades
                </option>
                {citiesForFilter?.map((city) => {
                  return (
                    <option className="text-black" value={city}>
                      {city}
                    </option>
                  );
                })}
              </select>

              <button
                onClick={() => setShowFilters(!showFilters)}
                className="cursor-pointer bg-amber-500 hover:bg-amber-600 text-black font-semibold px-6 py-3 rounded-lg transition flex items-center gap-2"
              >
                <Filter className="w-5 h-5" />
                Filtros
              </button>
              <button
                className="cursor-pointer bg-amber-500 hover:bg-amber-600 text-black font-semibold px-6 py-3 rounded-lg transition flex items-center gap-2"
                onClick={clearFiltros}
              >
                X
              </button>
            </div>

            {showFilters && (
              <Filtros
                selectedRating={minRating}
                onRatingChange={setMinRating}
                selectedPrice={selectedPrice}
                onPriceChange={setSelectedPrice}
              />
            )}
          </div>
        </div>

        <div className="mb-6">
          <p className="text-slate-300 text-lg">
            Encontramos{" "}
            <span className="text-amber-500 font-semibold">
              {filteredShops.length}
            </span>{" "}
            barbearias para você
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredShops.map((cardData) => (
            <div
              onClick={() =>
                handleOpenModal(barbearias.filter((b) => b.id === cardData.id))
              }
            >
              <CardBarbearia
                key={cardData.id}
                shop={cardData}
                barber={barbearias.filter((b) => b.id === cardData.id)[0]}
              />
            </div>
          ))}
        </div>
        {filteredShops.length === 0 && (
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-10 h-10 text-slate-500" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">
              Nenhuma barbearia encontrada
            </h3>
            <p className="text-slate-400">
              Tente ajustar seus filtros de busca
            </p>
          </div>
        )}
      </div>
      {open && (
        <ModalBarbearia
          barber={barberDetails}
          isOpen={open}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
}
