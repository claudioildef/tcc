export default function Filtros({
  selectedRating,
  onRatingChange,
  selectedPrice,
  onPriceChange,
}) {
  return (
    <div className="mt-6 pt-6 border-t border-white/10">
      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <label className="text-slate-300 text-sm mb-2 block">
            Avaliação mínima
          </label>
          <select
            value={selectedRating}
            onChange={(e) => onRatingChange(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-amber-500"
          >
            <option className="text-black" value="">
              Qualquer
            </option>
            <option className="text-black" value="3">
              3+ estrelas
            </option>
            <option className="text-black" value="4">
              4+ estrelas
            </option>
            <option className="text-black" value="4.9">
              4.9+ estrelas
            </option>
          </select>
        </div>
        <div>
          <label className="text-slate-300 text-sm mb-2 block">
            Faixa de preço
          </label>
          <select
            value={selectedPrice}
            onChange={(e) => onPriceChange(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-amber-500"
          >
            <option className="text-black" value="">
              Qualquer
            </option>
            <option className="text-black" value="$">
              $ - Econômico
            </option>
            <option className="text-black" value="$$">
              $$ - Moderado
            </option>
            <option className="text-black" value="$$$">
              $$$ - Premium
            </option>
          </select>
        </div>
      </div>
    </div>
  );
}
