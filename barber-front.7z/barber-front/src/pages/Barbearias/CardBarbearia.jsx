import { Clock, DollarSign, MapPin, Star } from "lucide-react";
import ModalBarbearia from "./ModalBarbearia";
import { useState } from "react";

export default function CardBarbearia({ shop, barber }) {
  const [open, setOpen] = useState(false);

  return (
    <div
      onClick={() => setOpen(true)}
      className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl overflow-hidden hover:border-amber-500/50 transition group cursor-pointer"
    >
      <div className="h-48 overflow-hidden relative">
        <img
          src={shop.image}
          alt={shop.name}
          className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
        />
        <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-sm px-3 py-1 rounded-full flex items-center gap-1">
          <DollarSign className="w-4 h-4 text-amber-500" />
          <span className="text-white text-sm font-semibold">{shop.price}</span>
        </div>
      </div>

      <div className="p-5">
        <h3 className="text-xl font-bold text-white mb-2 group-hover:text-amber-500 transition">
          {shop.name}
        </h3>
        <div className="flex items-center gap-2 text-slate-300 mb-3">
          <MapPin className="w-4 h-4 text-amber-500 flex-shrink-0" />
          <span className="text-sm">{shop.location}</span>
        </div>
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < Math.floor(shop.rating)
                    ? "fill-amber-500 text-amber-500"
                    : "text-slate-600"
                }`}
              />
            ))}
          </div>
          <span className="text-white font-semibold">{shop.rating}</span>
          <span className="text-slate-400 text-sm">({shop.reviews})</span>
        </div>
        <div className="flex items-center gap-2 text-slate-300 mb-4">
          <Clock className="w-4 h-4 text-amber-500" />
          <span className="text-sm">{shop.openHours}</span>
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {shop.services.map((service, index) => (
            <span
              key={index}
              className="bg-amber-500/10 text-amber-500 text-xs px-3 py-1 rounded-full border border-amber-500/20"
            >
              {service}
            </span>
          ))}
        </div>
        <button className="w-full bg-amber-500 hover:bg-amber-600 text-black font-semibold py-2 rounded-lg transition">
          Ver Detalhes
        </button>
      </div>
    </div>
  );
}
