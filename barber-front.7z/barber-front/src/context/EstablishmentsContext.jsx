import { createContext, useContext, useState } from "react";

const EstablishmentsContext = createContext();

export function EstablishmentsProvider({ children }) {
    const [establishments, setEstablishments] = useState([]);

    const addEstablishment = (data) => {
        setEstablishments((prev) => [...prev, { id: Date.now(), ...data }]);
    };

    const removeEstablishment = (id) => {
        setEstablishments((prev) => prev.filter((e) => e.id !== id));
    };

    return (
        <EstablishmentsContext.Provider
            value={{ establishments, addEstablishment, removeEstablishment }}
        >
            {children}
        </EstablishmentsContext.Provider>
    );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useEstablishments() {
    return useContext(EstablishmentsContext);
}
