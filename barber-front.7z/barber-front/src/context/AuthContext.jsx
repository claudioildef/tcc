import { createContext, useContext, useState } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);

    const login = (email, password) => {
        const fakeUser = { id: 1, name: "Usuário Demo", email };
        setUser(fakeUser);
        return true;
    };

    const logout = () => setUser(null);

    const register = (name, email, password) => {
        // mock de cadastro
        const newUser = { id: Date.now(), name, email };
        setUser(newUser);
        return true;
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, register, setUser    }}>
            {children}
        </AuthContext.Provider>
    );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
    return useContext(AuthContext);
}
