import React, { useState, useEffect} from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Header from "./components/Header";
import Protected from "./components/Protected";
import Home from "./pages/Home/Home";
import AuthPage from "./pages/AuthPage";
import Barbearias from "./pages/Barbearias/Barbearias";
import Profile from "./pages/Profile";
import { AuthProvider } from "./context/AuthContext";
import Footer from "./components/Footer";
import CadastrarBarbearia from "./pages/CadastroBarbearias/CadastrarBarbearia";

export default function App() {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem("bm_user")) || null);


  useEffect(() => {
    localStorage.setItem("bm_user", JSON.stringify(user));
  }, [user]);

  return (
    <AuthProvider value={{ user, setUser }}>
      <Header />
      <main className="p-4 max-w-5xl mx-auto">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/explorar" element={<Barbearias />} />
          <Route path="/perfil" element={<Protected><Profile /></Protected>} />
          <Route path="/cadastrar" element={<CadastrarBarbearia />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
    </AuthProvider>
  );
}