

export default function Footer() {
    return (
        <footer className="bg-black/30 backdrop-blur-md border-t border-white/10 mt-20">
            <div className="container mx-auto px-6 py-8 text-center text-slate-400">
                <p>© 2025 BarberConnect. Todos os direitos reservados.</p>
            </div>
        </footer>
    )
}
