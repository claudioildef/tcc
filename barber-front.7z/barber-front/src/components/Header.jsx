import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Scissors } from "lucide-react";

function NavLink({ to, children }) {
  return (
    <Link to={to} className="relative px-2 py-1 text-sm font-medium group">
      <span className="block">{children}</span>
      <span className="absolute left-0 -bottom-1 h-0.5 w-0 bg-gradient-to-r from-transparent to-white group-hover:w-full transition-all duration-300"></span>
    </Link>
  );
}

export default function Header() {
  return (
    <header className="bg-black/30 backdrop-blur-md border-b border-white/10">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Scissors className="w-8 h-8 text-amber-500" />
          <h1 className="text-2xl font-bold text-white">Barber+</h1>
        </div>
        <nav className="flex gap-6">
          <a href="/" className="text-white hover:text-amber-500 transition">
            Home
          </a>
          <a
            href="/explorar"
            className="text-white/70 hover:text-amber-500 transition"
          >
            Barbearias
          </a>
          <a
            href="/cadastrar"
            className="text-white/70 hover:text-amber-500 transition"
          >
            Cadastrar
          </a>
        </nav>
      </div>
    </header>
  );
}
