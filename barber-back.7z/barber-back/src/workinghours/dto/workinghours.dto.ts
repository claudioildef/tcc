export class WorkinghoursDto {
    dayOfWeek: string;
    openTime: string;
    closeTime: string;
}