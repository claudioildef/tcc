import { MigrationInterface, QueryRunner } from "typeorm";

export class AjustesId1761607104228 implements MigrationInterface {
    name = 'AjustesId1761607104228'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`services\` DROP PRIMARY KEY`);
        await queryRunner.query(`ALTER TABLE \`services\` DROP COLUMN \`id\``);
        await queryRunner.query(`ALTER TABLE \`services\` ADD \`id\` int NOT NULL PRIMARY KEY AUTO_INCREMENT`);
        await queryRunner.query(`ALTER TABLE \`working_hours\` DROP PRIMARY KEY`);
        await queryRunner.query(`ALTER TABLE \`working_hours\` DROP COLUMN \`id\``);
        await queryRunner.query(`ALTER TABLE \`working_hours\` ADD \`id\` int NOT NULL PRIMARY KEY AUTO_INCREMENT`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`working_hours\` DROP COLUMN \`id\``);
        await queryRunner.query(`ALTER TABLE \`working_hours\` ADD \`id\` varchar(36) NOT NULL`);
        await queryRunner.query(`ALTER TABLE \`working_hours\` ADD PRIMARY KEY (\`id\`)`);
        await queryRunner.query(`ALTER TABLE \`services\` DROP COLUMN \`id\``);
        await queryRunner.query(`ALTER TABLE \`services\` ADD \`id\` varchar(36) NOT NULL`);
        await queryRunner.query(`ALTER TABLE \`services\` ADD PRIMARY KEY (\`id\`)`);
    }

}
