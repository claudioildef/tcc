import { ConflictException, Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateBarberDto } from './dto/create-barber.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Barber } from 'src/db/entities/Barber';
import { DataSource, Repository } from 'typeorm';
import { Address } from 'src/db/entities/Address';
import { Service } from 'src/db/entities/Service';
import { WorkingHour } from 'src/db/entities/WorkingHour';

@Injectable()
export class BarberService {
  constructor(
    @InjectRepository(Barber)
    private readonly barberRepository: Repository<Barber>,

    @InjectRepository(Address)
    private readonly addressRepository: Repository<Address>,

    @InjectRepository(Service)
    private readonly serviceRepository: Repository<Service>,

    @InjectRepository(WorkingHour)
    private readonly workingHourRepository: Repository<WorkingHour>,
    private readonly dataSource: DataSource,
  ) {}

  async create(createBarberDto: CreateBarberDto): Promise<Barber | null> {
    return await this.dataSource.transaction(async (manager) => {
      const existingBarberShop = await manager.findOne(Barber, {
        where: { email: createBarberDto.email },
      });

      if (existingBarberShop) {
        throw new ConflictException('Já existe uma barbearia cadastrada com este email');
      }

      const address = manager.create(Address, {
        cep: createBarberDto.address.cep,
        street: createBarberDto.address.street,
        number: createBarberDto.address.number,
        complement: createBarberDto.address.complement,
        neighborhood: createBarberDto.address.neighborhood,
        city: createBarberDto.address.city,
        state: createBarberDto.address.state.toUpperCase(),
        latitude: createBarberDto.address.latitude,
        longitude: createBarberDto.address.longitude,
      });

      const savedAddress = await manager.save(Address, address);

      const DEFAULT_BARBER_LOGOS = [
        'https://images.pexels.com/photos/1813346/pexels-photo-1813346.jpeg',
        'https://images.pexels.com/photos/3998414/pexels-photo-3998414.jpeg',
        'https://images.pexels.com/photos/2061820/pexels-photo-2061820.jpeg',
        'https://images.unsplash.com/photo-1638383257653-4217e9161b11?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=687',
        'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=1170',
        'https://images.unsplash.com/photo-1621645582931-d1d3e6564943?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=764',
        'https://plus.unsplash.com/premium_photo-1661542350224-8e3f095ce053?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=687',
        'https://images.unsplash.com/photo-1592647420148-bfcc177e2117?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=1139',
        'https://plus.unsplash.com/premium_photo-1677444204875-f42713e1fac9?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=687',
        'https://plus.unsplash.com/premium_photo-1677444205097-de9282585eec?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=687',
        'https://images.unsplash.com/photo-1638383257653-4217e9161b11?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=687',
        'https://images.unsplash.com/photo-1598524374668-5d565a3c42e8?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=687',
        'https://images.unsplash.com/photo-1527512950678-b88a241e9f4b?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=1170',
        'https://images.unsplash.com/photo-1647140656295-61486627df99?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=764',
      ];

      const randomIndex = Math.floor(Math.random() * DEFAULT_BARBER_LOGOS.length);
      const randomLogoUrl = DEFAULT_BARBER_LOGOS[randomIndex];

      const barber = manager.create(Barber, {
        name: createBarberDto.name,
        email: createBarberDto.email,
        phone: createBarberDto.phone,
        whatsapp: createBarberDto.whatsapp,
        description: createBarberDto.description,
        priceRange: createBarberDto.priceRange,
        address: savedAddress,
        logo: randomLogoUrl,
      });

      const savedBarber = await manager.save(Barber, barber);

      const services = createBarberDto.services.map((serviceDto) =>
        manager.create(Service, {
          name: serviceDto.name,
          price: serviceDto.price,
          barberId: savedBarber.id,
          isActive: false,
          createdAt: new Date(),
        }),
      );

      await manager.save(Service, services);

      const workingHours = createBarberDto.selectedDays.map((day) =>
        manager.create(WorkingHour, {
          dayOfWeek: day,
          openTime: createBarberDto.openHour,
          closeTime: createBarberDto.closeHour,
          barberId: savedBarber.id,
        }),
      );

      await manager.save(WorkingHour, workingHours);

      return await manager.findOne(Barber, {
        where: { id: savedBarber.id },
        relations: ['address', 'services', 'workingHours'],
      });
    });
  }
  async findById(barberId: string) {
    return this.barberRepository.findOne({
      where: { id: barberId },
    });
  }

  async getAll() {
    return await this.barberRepository.find({
      relations: {
        reviews: true,
        services: true,
        workingHours: true,
        address: true,
      },
    });
  }
}
