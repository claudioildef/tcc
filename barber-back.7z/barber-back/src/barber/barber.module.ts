import { forwardRef, Module } from '@nestjs/common';
import { BarberController } from './barber.controller';
import { BarberService } from './barber.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Barber } from 'src/db/entities/Barber';
import { Address } from 'src/db/entities/Address';
import { Service } from 'src/db/entities/Service';
import { WorkingHour } from 'src/db/entities/WorkingHour';
import { ReviewModule } from 'src/review/review.module';

@Module({
  imports: [TypeOrmModule.forFeature([Barber, Address, Service, WorkingHour]), forwardRef(() => ReviewModule)],
  controllers: [BarberController],
  providers: [BarberService],
  exports: [BarberService],
})
export class BarberModule {}
