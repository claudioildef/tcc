import { Module } from '@nestjs/common';
import { AddressService } from './address.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Address } from 'src/db/entities/Address';

@Module({
  imports: [TypeOrmModule.forFeature([Address])],
  providers: [AddressService],
})
export class AddressModule {}
