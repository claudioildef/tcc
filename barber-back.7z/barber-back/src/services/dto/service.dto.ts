export class ServiceDto {
  name: string;
  price: number;
  duration: string;
}
