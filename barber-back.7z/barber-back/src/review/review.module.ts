import { forwardRef, Module } from '@nestjs/common';
import { ReviewService } from './review.service';
import { ReviewController } from './review.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Review } from 'src/db/entities/Review';
import { BarberService } from 'src/barber/barber.service';
import { BarberModule } from 'src/barber/barber.module';

@Module({
  providers: [ReviewService],
  imports: [TypeOrmModule.forFeature([Review]), forwardRef(() => BarberModule)],
  controllers: [ReviewController],
  exports: [ReviewService],
})
export class ReviewModule {}
