export class CreateReviewDto {
    customerName: string;
    rating: number;
    barberId: string;
}