export class CreateUserDto {

}
